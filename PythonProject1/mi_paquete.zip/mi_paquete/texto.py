
def contar_letras(texto):
    contador = 0
    for letra in texto:
        contador += 1
    print(contador)

def invertir_texto(texto):
    print(texto[::-1])
