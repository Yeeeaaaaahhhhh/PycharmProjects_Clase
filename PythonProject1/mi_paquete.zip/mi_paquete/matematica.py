def suma (a, b):
    print(a+b)
def resta (a, b):
    print(a-b)

